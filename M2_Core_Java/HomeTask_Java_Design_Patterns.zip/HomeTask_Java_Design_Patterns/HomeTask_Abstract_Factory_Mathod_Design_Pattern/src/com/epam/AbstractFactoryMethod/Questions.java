package com.epam.AbstractFactoryMethod;

public interface Questions {

	String askTime();
	
	String askWeather();
}
