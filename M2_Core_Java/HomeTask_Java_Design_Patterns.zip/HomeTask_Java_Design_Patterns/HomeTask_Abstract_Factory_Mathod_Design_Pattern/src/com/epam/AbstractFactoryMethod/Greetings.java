package com.epam.AbstractFactoryMethod;

public interface Greetings {

	String goodMorning();
	
	String goodAfternoon();
	
}
