package com.epam.AbstractFactoryMethod;

public interface MessagesAbstractFactory {
	
	Greetings getGreetings();
	
	Questions getQuestions();

}
