package com.epam.Strategy_Design_Pattern;

public interface Strategy {  
    
    public float calculation(float a, float b);  
  
}