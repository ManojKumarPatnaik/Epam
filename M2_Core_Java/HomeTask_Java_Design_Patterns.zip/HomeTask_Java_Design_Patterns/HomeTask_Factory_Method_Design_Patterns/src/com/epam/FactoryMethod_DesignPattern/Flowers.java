package com.epam.FactoryMethod_DesignPattern;

public interface Flowers {
	double getPrice(int quantity);

}
