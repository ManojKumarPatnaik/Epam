package com.epam.Decorator_DesignPattern;

public interface Pizza {
    public  void getPizza();
}