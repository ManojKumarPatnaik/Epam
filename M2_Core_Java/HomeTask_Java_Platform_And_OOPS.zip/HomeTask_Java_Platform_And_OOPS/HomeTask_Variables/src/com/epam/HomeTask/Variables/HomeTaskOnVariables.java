package com.epam.HomeTask.Variables;

public class HomeTaskOnVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int No_Of_Apples_Daniel=3;
		int No_Of_Apples_Amber=2;
		System.out.println("How many apples do Daniel and Amber have together = "+(No_Of_Apples_Daniel+No_Of_Apples_Amber)+" Apples");
		float Daniel=3.5f;
		float Amber=2.5f;
		System.out.println("How many apples do Daniel and Amber have together = "+(Daniel+Amber)+" Apples");
	}

}
