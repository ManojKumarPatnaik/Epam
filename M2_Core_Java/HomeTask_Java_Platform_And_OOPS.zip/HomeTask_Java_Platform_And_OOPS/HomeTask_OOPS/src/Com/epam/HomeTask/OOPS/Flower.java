package Com.epam.HomeTask.OOPS;

public abstract class Flower {
    int quantity;
    public abstract double getPrice();

}