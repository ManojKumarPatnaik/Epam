package Com.epam.HomeTask.OOPS.NewYearGift;

public abstract class Gift {

	public int sumOfTheQuantity(int sum) {

		return sum;
	}

	public int countOfTheQuantity(int count) {

		return count;
	}
}
