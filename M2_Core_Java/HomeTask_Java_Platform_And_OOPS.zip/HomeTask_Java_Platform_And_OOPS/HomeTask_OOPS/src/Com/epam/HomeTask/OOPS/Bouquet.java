package Com.epam.HomeTask.OOPS;

public interface Bouquet {
    void getPrice();
}

